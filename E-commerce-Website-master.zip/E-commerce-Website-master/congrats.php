Added to Cart

<a href="cart.php">View Cart</a>
<a href="list.php">Add more</a>